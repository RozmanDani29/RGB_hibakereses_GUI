﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using static System.Net.Mime.MediaTypeNames;
using RGB_img.Models;

namespace RGB_img
{
    public partial class MainWindow : Window
    {
        const int Columns = 640;
        const int Rows = 360;
        const int CellSize = 1;

        ImageMatrix image;

        string path = System.IO.Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory,
            "Data",
            "kep.txt"
        );

        public MainWindow()
        {
            InitializeComponent();
            image = new ImageMatrix();
            image.LoadFromFile(path);
            DrawGrid();
        }

        private void DrawGrid()
        {
            MainCanvas.Width = Columns * CellSize;
            MainCanvas.Height = Rows * CellSize;

            // ❌ fel volt cserélve → helyes
            for (int x = 0; x < Rows; x++)
            {
                for (int y = 0; y < Columns; y++)
                {
                    Pixel p = image.Pixels[x, y];

                    var rect = new Rectangle
                    {
                        Width = CellSize,
                        Height = CellSize,
                        // ❌ hiányzott az alfa → 255
                        Fill = new SolidColorBrush(
                            Color.FromArgb(255, p.R, p.G, p.B))
                    };

                    Canvas.SetLeft(rect, y * CellSize); 
                    Canvas.SetTop(rect, x * CellSize); 

                    MainCanvas.Children.Add(rect);
                }
            }
        }
    }
}
